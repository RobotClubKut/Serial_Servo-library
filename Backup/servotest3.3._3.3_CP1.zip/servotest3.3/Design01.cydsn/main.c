/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

void init_ID(void);
void init_speed(uint8 id, uint8 speed);
void servo(uint8 id, uint8 kakudo, uint8 power);

int main()
{
    UART_servo_Start();
    UART_Debug_Start();
    CyGlobalIntEnable; /* Enable global interrupts. */
    CyDelay(1000);

    //init_ID();
    //init_speed(3, 100);
    
    for(;;)
    {
        /* Place your application code here. */
        servo(3, 180, 0);
        CyDelay(10);
        //servo(4, 180);
    }
}

void init_ID(void){
    uint8 i;
    unsigned char write_id[4];
    write_id[0] = 0xE0 | 3;
    write_id[1] = 0x01;
    write_id[2] = 0x01;
    write_id[3] = 0x01;
    for(i = 0; i < 4; i++){
        UART_servo_PutChar(write_id[i]);
    }
    CyDelay(1);
}

void init_speed(uint8 id, uint8 speed)
{
    uint8 i;
    unsigned char write_speed[3] = {0,0,0};
    write_speed[0] = 0xC0 | id;
    write_speed[1] = 0x02;
    write_speed[2] = (unsigned char) speed;
    for(i = 0; i < 3; i++){
        UART_servo_PutChar(write_speed[i]);
    }        
    CyDelay(1);
}

void servo(uint8 id, uint8 kakudo, uint8 pf){
    uint8 i;
    int servo_Data = 0;
    uint8 posf, pos_l, pos_h, pos;
    char buf[40];
    unsigned char tx[3];
    unsigned char rx[6];
    
    if(pf == 1){
        servo_Data = 10000 -( 30 * kakudo );
        tx[0] = 0x80 | id;
        tx[1] = (unsigned char)(servo_Data>>7) & 0x7F;
        tx[2] = (unsigned char)servo_Data & 0x7F;
        for(i = 0; i < 3; i++){
            UART_servo_PutChar(tx[i]);
        }
        CyDelay(1);
    } else {
        servo_Data = kakudo * 0;
        tx[0] = 0x80 | id;
        tx[1] = (unsigned char)(servo_Data>>7) & 0x7F;
        tx[2] = (unsigned char)servo_Data & 0x7F;
        for(i = 0; i < 3; i++){
            UART_servo_PutChar(tx[i]);
        }
        CyDelay(1);
        for(i = 0; i < 6; i++){
            rx[i] = (unsigned char) UART_servo_GetChar();
        }
        CyDelay(1);
        pos_h = ((uint16)rx[4]<<7) & 0x3f80;
        pos_l = (uint16)rx[5] & 0x7f;
        pos = pos_h | pos_l;
        posf = rx[3] & 0x7f;
        sprintf(buf, "%d %d\n", posf, pos);
        UART_Debug_PutString(buf);
    }
}
/* [] END OF FILE */
